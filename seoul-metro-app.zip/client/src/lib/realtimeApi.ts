/**
 * 서울교통공사 실시간 도착 정보 API 연동
 * 
 * 서버 측 프록시를 통해 API 키를 안전하게 관리합니다.
 * tRPC를 통해 서버에 요청하고, 서버가 Seoul Metro API를 호출합니다.
 * 
 * tRPC를 사용할 수 없는 컨텍스트에서는 직접 /api/trpc 엔드포인트를 호출합니다.
 */

export interface ArrivalInfo {
  stationName: string;
  lineId: string;
  direction: string;
  destination: string;
  arrivalMessage: string; // "3분 후", "전역 출발" 등
  arrivalTime: number; // 초 단위
  trainType: string; // "일반", "급행"
  currentStation: string;
}

/**
 * 실시간 도착 정보 가져오기 (서버 프록시 경유)
 */
export async function getRealtimeArrivals(stationName: string): Promise<ArrivalInfo[]> {
  try {
    // tRPC batch endpoint를 직접 호출 (React 외부에서 사용 가능)
    const url = `/api/trpc/metro.getArrivals?batch=1&input=${encodeURIComponent(
      JSON.stringify({ "0": { json: { stationName } } })
    )}`;
    
    const response = await fetch(url, { credentials: "include" });
    
    if (!response.ok) {
      return generateSimulatedArrivals(stationName);
    }

    const data = await response.json();
    const result = data[0]?.result?.data?.json;
    
    if (result?.arrivals) {
      return result.arrivals;
    }
    
    return generateSimulatedArrivals(stationName);
  } catch (error) {
    console.warn("서버 프록시 연결 실패, 시뮬레이션 데이터 사용:", error);
    return generateSimulatedArrivals(stationName);
  }
}

/**
 * API 키 상태 확인 (서버에 키가 설정되어 있는지)
 */
export async function checkApiKeyStatus(): Promise<boolean> {
  try {
    const url = `/api/trpc/metro.getApiStatus?batch=1&input=${encodeURIComponent(
      JSON.stringify({ "0": { json: null } })
    )}`;
    const response = await fetch(url, { credentials: "include" });
    if (!response.ok) return false;
    const data = await response.json();
    return data[0]?.result?.data?.json?.hasApiKey ?? false;
  } catch {
    return false;
  }
}

/**
 * 시뮬레이션 도착 정보 생성 (폴백)
 */
function generateSimulatedArrivals(stationName: string): ArrivalInfo[] {
  const directions = [
    { direction: "상행", destinations: ["소요산", "대화", "당고개", "방화"] },
    { direction: "하행", destinations: ["인천", "오금", "오이도", "상일동"] },
  ];

  const arrivals: ArrivalInfo[] = [];

  directions.forEach(dir => {
    const count = Math.floor(Math.random() * 2) + 1;
    for (let i = 0; i < count; i++) {
      const minutes = Math.floor(Math.random() * 8) + 1;
      const dest = dir.destinations[Math.floor(Math.random() * dir.destinations.length)];
      arrivals.push({
        stationName,
        lineId: "2",
        direction: `${dest} 방면`,
        destination: dest,
        arrivalMessage: minutes <= 1 ? "곧 도착" : `${minutes}분 후`,
        arrivalTime: minutes * 60,
        trainType: Math.random() > 0.8 ? "급행" : "일반",
        currentStation: `${Math.floor(Math.random() * 3) + 1}정거장 전`,
      });
    }
  });

  return arrivals.sort((a, b) => a.arrivalTime - b.arrivalTime);
}

/**
 * 실시간 혼잡도 정보 (2차 기능 - 더미)
 */
export interface CongestionInfo {
  carNumber: number;
  level: "여유" | "보통" | "혼잡" | "매우혼잡";
  percentage: number;
}

export function getSimulatedCongestion(): CongestionInfo[] {
  return Array.from({ length: 10 }, (_, i) => {
    const percentage = Math.floor(Math.random() * 80) + 20;
    let level: CongestionInfo["level"];
    if (percentage < 40) level = "여유";
    else if (percentage < 60) level = "보통";
    else if (percentage < 80) level = "혼잡";
    else level = "매우혼잡";
    
    return { carNumber: i + 1, level, percentage };
  });
}
